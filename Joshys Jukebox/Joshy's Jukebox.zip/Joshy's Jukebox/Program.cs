﻿namespace JoshysJukebox
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] albums =
            {
                "Master Of Puppets by Metallica",
                "Paranoid by Black Sabbath",
                "Reign in Blood by Slayer",
                "Ride the Lightning by Metallica",
                "Killers by Iron Maiden",
                "Rust In Peace by Megadeath",
                "British Steel by Judas Priest",
                "The Number of the Beast by Iron Maiden",
                "Ace of Spades by Motorhead",
                "Holy Diver by Dio",
                "Joshua Tree by U2",
                "Rumours by Fleetwood Mac",
                "Tracy Chapman by Tracy  Chapman",
                "Dark side of the moon by Pink Floyd",
                "Hot Fuss by The Killers",
                "Back to Black by Amy Winehouse",
                "Californication by Red Hot Chili Peppers",
                "Dookie by Greenday",
                "Born this way by Lady Gaga",
                "Automatic for the People by R.E.M",
                "Jagged little pill by Alanis Morisette",
            };
            bool shuffled = false;
            Console.Clear();
            Console.WriteLine("Welcome to Joshy's Jukebox \n\n");
            Console.WriteLine($"The albums have been shuffled? {shuffled}");
            Console.WriteLine($"\nNow shuffling the albums");
            do
                shuffle();
            while (shuffled == false);
            void shuffle()
                {
                int lastIndex = albums.Count() - 1;
                int shuffleCount = 0;
                while (lastIndex > 0)
                    {
                    shuffled = true;
                    string tempValue = albums[lastIndex];
                    int randomIndex = new Random().Next(0, lastIndex);
                    albums[lastIndex] = albums[randomIndex];
                    albums[randomIndex] = tempValue;
                    lastIndex--;
                    shuffleCount++;
                    }
                        {
                    //Console.WriteLine("\nShuffle finished\n");
                    Console.WriteLine($"\nThe array has been shuffled:{shuffleCount} times");
                    Console.WriteLine($"\n\tThe album to listen to this week is:\n\n\t{albums[0]}");
                    // Console.WriteLine("\nThis is the shuffled contents of the Array:\n{0}", string.Join("\n", albums));
                    Console.WriteLine("\nDo you wish to shuffle again? (Y or N)");
                    string menuChoice = Console.ReadLine();
                    if (menuChoice == "Y")
                        {
                            Console.Clear();
                            shuffle();
                        }
                    else if (menuChoice == "N")
                        { 
                        Console.WriteLine("\nGoodbye");
                        Environment.Exit(0);
                        }
                    }
            }
        }
    }
}